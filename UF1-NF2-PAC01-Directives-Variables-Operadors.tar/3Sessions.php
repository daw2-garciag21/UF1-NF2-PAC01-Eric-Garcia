<?php
echo "Bienvenido a nuestro sitio web, ";
echo $_SESSION["username"];
echo "! <br/>";
unset($_SESSION["newsession"]);
/*session deleted. if you try using this you've got an error*/

echo "Welcome to our site, ";
echo $_COOKIE["username"];
echo "! <br/>";

echo "Mi serie favorita son los protegidos ";
echo $_GET['favmovie'];
$movierate = 7;
echo "La nota que le pongo a esta serie es: ";
echo $movierate;
if ($_SESSION['authuser'] != 1){
    echo "Lo siento, no estás autorizado para ver esta página!";
    exit();  
}
?>
<html>
 <head>
  <title>My Movie Site <?php echo $_GET['favmovie'];?></title>
 </head>
 <body>
<a href="destino.php?variable1=valor1&variable2=valor2">Mi enlace</a>
</body>
</html>
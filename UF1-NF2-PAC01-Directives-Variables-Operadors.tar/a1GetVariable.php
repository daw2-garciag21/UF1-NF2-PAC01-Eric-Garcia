<html>
 <head>
  <title>Cuantos capítulos tuvo cada mes de media los protegidos??</title>
 </head>
 <body>
<?php
echo '¡Hola ' . htmlspecialchars($_GET["nombre"]) . '!';
echo "Bienvenido a nuestro sitio web, ";
echo $_SESSION["username"];
echo "! <br/>";
unset($_SESSION["newsession"]);
/*session deleted. if you try using this you've got an error*/
date_default_timezone_set('Spain/Madrid');
$month = date('n');
if ($month ==  1) { echo '4'; }
if ($month ==  2) { echo '5 (unless it\'s a leap year)'; }
if ($month ==  3) { echo '3'; }
if ($month ==  4) { echo '4'; }
if ($month ==  5) { echo '5'; }
if ($month ==  6) { echo '4'; }
if ($month ==  7) { echo '4'; }
if ($month ==  8) { echo '4'; }
if ($month ==  9) { echo '4'; }
if ($month == 10) { echo '4'; }
if ($month == 11) { echo '5'; }
if ($month == 12) { echo '4'; }
if ($_SESSION['authuser'] != 1){
    echo "Lo siento, no estás autorizado para ver esta página!";
    exit();  
}
?></body>
</html>
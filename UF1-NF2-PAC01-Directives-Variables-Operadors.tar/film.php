<?php
session_start();

//Check user permission
?>
<html>
 <head>
  <title>My Movie Site <?php echo $_GET['favmovie'];?></title>
 </head>
 <body>
<?php
echo "Bienvenido al sitio web de mi videojuego favorito, ";
echo $_SESSION["username"];
echo "! <br/>";

echo "Mi videojuego favorito es metal gear solid 3 que fue creado por Kojima y Konami ";
echo $_GET['favmovie'];
$movierate = 10;
echo "La nota del juego es: ";
echo $movierate;
?>
 </body>
</html>

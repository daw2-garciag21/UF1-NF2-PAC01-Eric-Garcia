
<html>
 <head>
  <title>Find my Favorite Movie!</title>
 </head>
 <body>
<?php
echo "<a href='N2P103MovieSite.php?favmovie=Stripes'>";
echo "Click here to see information about my favorite movie!"; 
echo "</a>";
?>
 </body>
</html>

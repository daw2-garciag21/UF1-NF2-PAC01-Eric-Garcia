<HTML>
<HEAD>
<TITLE>destino.php</TITLE>
</HEAD>
<BODY>

  Variable "saludo": <?php echo $_GET["saludo"]; ?> 
  <br>
  Variable "texto" <?php echo $_GET["texto"]; ?>
 
</BODY>
</HTML>
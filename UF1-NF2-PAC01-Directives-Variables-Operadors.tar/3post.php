<html> 
<head> 
  <title>Restringir por edad</title> 
</head> 
<body> 
<form action="3post.php" method="post"> 
Escribe tu edad: <input type="text" name="edad" size="2"> 
<input type="submit" value="Entrar"> 
</form> 
<? 
$edad = $_POST["edad"]; 
echo "Tu edad: $edad<p>"; 
$a = '';
if($a == NULL) {
    echo 'is null';
  }
if ($edad < 18) { 
  	echo "No puedes entrar"; 
}else{ 
  	echo "Bienvenido"; 
} 
?> 
<?php
$myfavmovie = urlencode("Metal Gear Solid 3");
echo "<a href='film.php?favmovie=$myfavmovie'>";
echo "Haz click para ver más información de mi videojuego favorito!"; 
echo "</a>";
?>
</body> 
</html>
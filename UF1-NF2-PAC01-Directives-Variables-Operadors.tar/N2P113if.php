<?php
$a = 5;
$b = 3;
if ($a > $b) {
  echo "a es mayor que b";
}
?>

<html>
 <head>
  <title>Ejercicio 2</title>
 </head>
 <body>
     <ol>
         <li>Un poco más acerca de Eclipse</li>
         <li>saber que la variable session se pone arriba del todo</li>
         <li>usar la variable date function</li>
         <li>vincular un archivo a otro con una etiqueta</li>
         <li>hacer un formulario</li>
         <li>hacer un formulario donde podemos iniciar sesión y si no eres el usuario no ver datos</li>
         <li>saber que a veces puede dar un error de que no se puede visualizar un fichero y es un problema de cookies de google</li>
         <li>Devolver valores en true y false</li>
         <li>saber que el echo es como un printf en programación(/li>
         <li>como hacer tablas con php</li>  
     </ol>
    <p>Más o menos diría que la valoración en nota sería un 7,5</p>
    <p>De nota me pondría un 5</p>
    <p>No es tanto mejorar sino que la dificultad del ejercicio me parece alta para mi nivel</p>
<?php
?>
 </body>
</html>
